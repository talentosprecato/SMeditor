
import React, { useState, useEffect } from 'react';
import { SocialPost } from '../types';
import { PLATFORM_CONFIG } from '../constants';

interface SocialPostCardProps {
  post: SocialPost;
}

export const SocialPostCard: React.FC<SocialPostCardProps> = ({ post }) => {
  const [isCopied, setIsCopied] = useState(false);
  const config = PLATFORM_CONFIG[post.platform];

  useEffect(() => {
    if (isCopied) {
      const timer = setTimeout(() => setIsCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [isCopied]);

  const handleCopy = () => {
    navigator.clipboard.writeText(post.text);
    setIsCopied(true);
  };
  
  // Format text for display (e.g., newlines for Instagram)
  const formattedText = post.text.split('\\n').map((line, index) => (
    <React.Fragment key={index}>
      {line}
      <br />
    </React.Fragment>
  ));

  return (
    <div className={`bg-gray-800 rounded-xl overflow-hidden shadow-lg border-t-4 ${config.color} flex flex-col transition-transform duration-300 hover:scale-105`}>
      <div className="p-5 flex justify-between items-center bg-gray-800/50">
        <div className="flex items-center gap-3">
          {config.icon}
          <h3 className="text-xl font-bold text-white">{post.platform}</h3>
        </div>
      </div>
      
      <div className="relative w-full" style={{ aspectRatio: config.aspectRatio.replace(':', '/') }}>
        <img src={post.imageUrl} alt={`Generated for ${post.platform}`} className="absolute top-0 left-0 w-full h-full object-cover"/>
      </div>
      
      <div className="p-5 flex-grow flex flex-col">
        <div className="text-gray-300 whitespace-pre-wrap text-sm leading-relaxed flex-grow">
          {formattedText}
        </div>
        <button
          onClick={handleCopy}
          className={`mt-4 w-full py-2 px-4 rounded-lg font-semibold transition-colors duration-200 ${
            isCopied ? 'bg-green-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
          }`}
        >
          {isCopied ? 'Copied!' : 'Copy Text'}
        </button>
      </div>
    </div>
  );
};
