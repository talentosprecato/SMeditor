
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="py-6 bg-gray-900/50 backdrop-blur-sm border-b border-gray-700/50 sticky top-0 z-10">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-3xl md:text-4xl font-bold">
          <span className="bg-gradient-to-r from-purple-500 to-indigo-500 text-transparent bg-clip-text">
            AI Social Content Generator
          </span>
        </h1>
        <p className="text-gray-400 mt-2 text-sm md:text-base">
          Craft perfect posts for every platform from a single idea.
        </p>
      </div>
    </header>
  );
};
