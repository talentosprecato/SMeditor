
import React from 'react';
import { SocialPost } from '../types';
import { SocialPostCard } from './SocialPostCard';

interface ResultsDisplayProps {
  posts: SocialPost[];
}

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ posts }) => {
  return (
    <div className="mt-12">
       <h2 className="text-2xl font-bold text-center mb-8 bg-gradient-to-r from-purple-400 to-indigo-400 text-transparent bg-clip-text">Your Generated Content</h2>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {posts.map((post) => (
          <SocialPostCard key={post.platform} post={post} />
        ))}
      </div>
    </div>
  );
};
