
import React, { useState } from 'react';
import { Tone } from '../types';
import { TONES } from '../constants';

interface InputFormProps {
  onGenerate: (idea: string, tone: Tone) => void;
  isLoading: boolean;
}

export const InputForm: React.FC<InputFormProps> = ({ onGenerate, isLoading }) => {
  const [idea, setIdea] = useState<string>('');
  const [selectedTone, setSelectedTone] = useState<Tone>(TONES[0]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(idea, selectedTone);
  };

  return (
    <form onSubmit={handleSubmit} className="p-6 bg-gray-800 rounded-xl shadow-lg space-y-6 border border-gray-700">
      <div>
        <label htmlFor="idea" className="block text-lg font-medium text-gray-300 mb-2">
          1. Enter your content idea
        </label>
        <textarea
          id="idea"
          rows={3}
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          className="w-full bg-gray-700/50 text-white rounded-lg p-3 border border-gray-600 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-200 resize-none"
          placeholder="e.g., The launch of a new sustainable coffee brand"
        />
      </div>
      <div>
        <label className="block text-lg font-medium text-gray-300 mb-3">
          2. Select a tone
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {TONES.map((tone) => (
            <button
              key={tone}
              type="button"
              onClick={() => setSelectedTone(tone)}
              className={`py-2 px-4 text-sm font-semibold rounded-full transition-all duration-200 transform hover:scale-105 ${
                selectedTone === tone
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              {tone}
            </button>
          ))}
        </div>
      </div>
      <button
        type="submit"
        disabled={isLoading || !idea.trim()}
        className="w-full flex justify-center items-center py-3 px-6 border border-transparent rounded-full shadow-sm text-lg font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500"
      >
        {isLoading ? 'Generating...' : '✨ Generate Content'}
      </button>
    </form>
  );
};
