// Fix: Import ReactElement for typing JSX components.
import type { ReactElement } from 'react';

export enum Tone {
  Professional = 'Professional',
  Witty = 'Witty',
  Urgent = 'Urgent',
  Inspirational = 'Inspirational',
  Casual = 'Casual',
}

export enum Platform {
    LinkedIn = 'LinkedIn',
    Twitter = 'Twitter/X',
    Instagram = 'Instagram',
}

export type AspectRatio = '1:1' | '4:3' | '3:4' | '16:9' | '9:16';

export interface SocialPost {
  platform: Platform;
  text: string;
  imageUrl: string;
}

export interface PlatformConfig {
  icon: ReactElement;
  aspectRatio: AspectRatio;
  color: string;
}