
import { GoogleGenAI, Type } from "@google/genai";
import { Tone, AspectRatio } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const textGenerationModel = 'gemini-2.5-pro';
const imageGenerationModel = 'imagen-4.0-generate-001';

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        imagePrompt: { 
            type: Type.STRING,
            description: "A concise, visually descriptive prompt for an image generation AI. It should be a single sentence describing a scene, without mentioning brands or text."
        },
        linkedin: { 
            type: Type.STRING,
            description: "A professional, long-form post for LinkedIn, including paragraphs and relevant business-oriented hashtags."
        },
        twitter: { 
            type: Type.STRING,
            description: "A short, punchy tweet for Twitter/X, under 280 characters, with 2-3 relevant hashtags."
        },
        instagram: { 
            type: Type.STRING,
            description: "A visually-focused caption for Instagram, followed by a line break and 5-7 relevant, popular hashtags."
        },
    },
    required: ["imagePrompt", "linkedin", "twitter", "instagram"]
};

interface SocialContentResponse {
    imagePrompt: string;
    linkedin: string;
    twitter: string;
    instagram: string;
}

export const generateSocialPosts = async (idea: string, tone: Tone): Promise<SocialContentResponse> => {
    try {
        const prompt = `
            Based on the following idea and desired tone, generate social media content for LinkedIn, Twitter/X, and Instagram.
            Also, create a concise, visually descriptive prompt for an image generation AI that captures the essence of the idea.

            Idea: "${idea}"
            Tone: "${tone}"

            Provide the output in the specified JSON format.
            - For LinkedIn, create a professional, longer-form post.
            - For Twitter/X, write a short, punchy tweet under 280 characters.
            - For Instagram, write a visually-focused caption and include 5-7 relevant hashtags.
            - The image prompt should be a single sentence describing a scene, suitable for a text-to-image model.
        `;
        
        const response = await ai.models.generateContent({
            model: textGenerationModel,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
                temperature: 0.8,
            },
        });

        const jsonText = response.text.trim();
        return JSON.parse(jsonText);
    } catch (error) {
        console.error("Error generating social posts:", error);
        throw new Error("Failed to get a valid response from the text generation model.");
    }
};

export const generateImage = async (prompt: string, aspectRatio: AspectRatio): Promise<string> => {
    try {
        const response = await ai.models.generateImages({
            model: imageGenerationModel,
            prompt: `cinematic photo, ${prompt}`, // Add some style guidance
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: aspectRatio,
            },
        });

        if (response.generatedImages && response.generatedImages.length > 0) {
            const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
            return `data:image/jpeg;base64,${base64ImageBytes}`;
        } else {
            throw new Error("No image was generated.");
        }
    } catch (error) {
        console.error(`Error generating image for prompt "${prompt}" with aspect ratio ${aspectRatio}:`, error);
        throw new Error(`Failed to generate an image for the prompt. The model may have safety concerns with the provided text.`);
    }
};
