
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { InputForm } from './components/InputForm';
import { ResultsDisplay } from './components/ResultsDisplay';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import { generateSocialPosts, generateImage } from './services/geminiService';
import { Tone, SocialPost, Platform } from './types';
import { PLATFORM_CONFIG } from './constants';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<SocialPost[] | null>(null);

  const handleGenerate = useCallback(async (idea: string, tone: Tone) => {
    if (!idea.trim()) {
      setError("Please enter a content idea.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setResults(null);

    try {
      // Step 1: Generate all text content and the master image prompt
      const textContent = await generateSocialPosts(idea, tone);
      if (!textContent) {
        throw new Error("Failed to generate text content.");
      }
      const { imagePrompt, linkedin, twitter, instagram } = textContent;

      // Step 2: Generate images for each platform in parallel
      const imagePromises = Object.keys(PLATFORM_CONFIG).map(platform => 
        generateImage(imagePrompt, PLATFORM_CONFIG[platform as Platform].aspectRatio)
      );
      
      const images = await Promise.all(imagePromises);

      const generatedPosts: SocialPost[] = [
        { platform: Platform.LinkedIn, text: linkedin, imageUrl: images[0] },
        { platform: Platform.Twitter, text: twitter, imageUrl: images[1] },
        { platform: Platform.Instagram, text: instagram, imageUrl: images[2] },
      ];

      setResults(generatedPosts);

    } catch (err) {
      console.error("Content generation failed:", err);
      setError(err instanceof Error ? err.message : "An unknown error occurred. Please check the console and try again.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white font-sans antialiased">
      <Header />
      <main className="container mx-auto px-4 py-8 md:py-12">
        <div className="max-w-3xl mx-auto">
          <InputForm onGenerate={handleGenerate} isLoading={isLoading} />
          {isLoading && <LoadingSpinner />}
          {error && <ErrorMessage message={error} />}
          {results && !isLoading && <ResultsDisplay posts={results} />}
        </div>
      </main>
    </div>
  );
};

export default App;
